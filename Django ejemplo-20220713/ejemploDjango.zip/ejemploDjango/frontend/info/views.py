import json
import re
from unicodedata import name
from django.shortcuts import render
from .models import Medicine
import requests

# Create your views here.

def getMedicineFromServer(requests):
    list = getMedicines()
    sendXmlToServer()
    for medicine in list:
        print(medicine)
        Medicine.objects.create(name = medicine['name'], price = medicine['price'])

    return render(requests, 'info/info.html', {'medicines': Medicine.objects.all()})





def getMedicines():
    return json.loads(requests.get('http://127.0.0.1:5000/medicine').text)

def sendXmlToServer():
    data = {'xml': 'este es mi xml'}
    r = requests.post(
            'http://127.0.0.1:5000/xml', json=data)
    print('> Server devolvio: ', r.text)
   


