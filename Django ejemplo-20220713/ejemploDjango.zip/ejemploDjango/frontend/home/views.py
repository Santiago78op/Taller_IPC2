from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def welcome(requests):
    return HttpResponse("HELLO, WORLD!!")

def welcomeTemplate(requests):
    return render(requests, 'home/welcome.html', {'name': 'Jose Carlos'})
