class NodoEncabezado():
    def __init__(self, id = None):
        self.id = id
        self.siguiente = None
        self.anterior = None
        self.acceso = None  #APUNTADOR A NODOS INTERNOS