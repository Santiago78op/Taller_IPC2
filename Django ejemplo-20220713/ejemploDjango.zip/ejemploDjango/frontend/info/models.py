from django.db import models

# Create your models here.

class Medicine(models.Model):
    name = models.TextField()
    price = models.FloatField()
